push_*.py 识别为推送插件
