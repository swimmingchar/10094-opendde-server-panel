

function pRead(){
	var readme = '<ul class="help-info-text c7">';
    readme += '<li>修改后,点击重启按钮</li>';
    readme += '</ul>';

    $('.soft-man-con').html(readme);   
}